﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;

namespace HardwareShop // Do not change the namespace name
{
    public class Program // Do not change the class name
    {
        public static void Main(string[] args)  // Do not change the 'Main' method signature
        {
            
            ComponentsUtility comobj = new ComponentsUtility();
            int choice = 0;
            //Implement your code here
            while (choice != 4)
            {
                Console.WriteLine("1. Validate Specification\n2.Calculate Total Price\n3.Calculate Discounted Price\n4.Exit");
                Console.WriteLine("Enter your choice");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter the CPU");
                            string c= Console.ReadLine();
                            comobj.CPU = c;
                            Console.WriteLine("Enter the RAM");
                            comobj.RAM=int.Parse(Console.ReadLine());
                            if(comobj.ValidateSpecification())
                            {
                                Console.WriteLine("Valid specification");
                            }
                            else
                            { Console.WriteLine("Invalid specification");
                            }
                            break;
                        }
                        case 2:
                        {
                            Console.WriteLine("Total Price:" + comobj.CalculateTotalPrice());
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Discounted Price: "+comobj.CalculateDiscountedPrice());
                            break;
                        }

                }

            }


        }
    }
}
