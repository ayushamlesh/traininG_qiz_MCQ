﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HardwareShop // Do not change the namespace name
{
    public class Components // Do not change the class name
    {
       //Implement your code here
       string cpu;
       int ram;
       int ssd;
       int gpu;
       int psu;
       double totalPrice;
       double discountedPrice;
       
       //public properties
       public string CPU
       { 
           set{cpu=value;}
           get{return cpu;}
       }
       public int RAM
       {
           set{ram=value;}
           get{return ram;}
       }
       public int SSD
       {
           set{ssd=value;}
           get{return ssd;}
       }
       public int GPU
       {
           set{gpu=value;}
           get{return gpu;}
       }
        public int PSU
        {
            set { psu = value; }
            get { return psu; }
        }
        public double TotalPrice
       {
           set{totalPrice=value;}
           get{return totalPrice;}
       }
       public double DiscountedPrice
       {
           set{discountedPrice=value;}
           get{return discountedPrice;}
       }
       
    }
}