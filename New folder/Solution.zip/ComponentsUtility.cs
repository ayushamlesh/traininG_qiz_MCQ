﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HardwareShop // Do not change the namespace name
{
    public class ComponentsUtility : Components // Do not change the class name
    {
        public bool ValidateSpecification()
        {

            

            if (CPU == "Ryzen3" | CPU == "Ryzen5" | CPU == "Ryzen7" | CPU == "Ryzen9")
            {
                if (RAM >= 8 && (RAM % 8 == 0))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
            public double CalculateTotalPrice()
            {
                Console.WriteLine("Enter the CPU");
                string C = Console.ReadLine();
                Console.WriteLine("Enter the RAM");
                RAM = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the SSD size");
                SSD = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the GPU size");
                GPU = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the PSU size");
                PSU = int.Parse(Console.ReadLine());

                if (C=="Ryzen3")
                {
                TotalPrice = 12500 + (RAM * 375) + (SSD * 7) + (GPU * 1750) + (PSU * 15);
                }
                else if(C=="Ryzen5")
                {
                TotalPrice = 17500 + (RAM * 375) + (SSD * 7) + (GPU * 1750) + (PSU * 15);
                }
                else if (C == "Ryzen7")
                {
                TotalPrice = 29000 + (RAM * 375) + (SSD * 7) + (GPU * 1750) + (PSU * 15);
                }
                else 
                {
                TotalPrice = 54000 + (RAM * 375) + (SSD * 7) + (GPU * 1750) + (PSU * 15);
                }
            return TotalPrice;
            }
        public double CalculateDiscountedPrice()
        {
            Console.WriteLine("Enter Total Price");
            TotalPrice = int.Parse(Console.ReadLine());
            if(TotalPrice<=50000)
            {
                DiscountedPrice = TotalPrice - (TotalPrice * 0.15);
               
            }
            else if (TotalPrice> 50000 && TotalPrice<=200000)
            {
                DiscountedPrice = TotalPrice - (TotalPrice * 0.20);
             
            }
            else if (TotalPrice > 200000)
            {
                DiscountedPrice = TotalPrice - (TotalPrice * 0.25);
              
            }
        return DiscountedPrice;

        }
            //Implement your code here
        }
    }
